//Numpy array shape [5]
//Min -0.125000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[5];
#else
bias5_t b5[5] = {0.000, 0.000, 0.000, 0.000, -0.125};
#endif

#endif
