//Numpy array shape [5, 2]
//Min 0.000000000000
//Max 0.875000000000
//Number of zeros 7

#ifndef W8_H_
#define W8_H_

#ifndef __SYNTHESIS__
weight8_t w8[10];
#else
weight8_t w8[10] = {0.625, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.875, 0.000, 0.750};
#endif

#endif
