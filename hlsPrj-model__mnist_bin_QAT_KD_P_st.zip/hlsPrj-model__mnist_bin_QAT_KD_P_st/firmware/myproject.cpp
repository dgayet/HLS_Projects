#include <iostream>

#include "myproject.h"
#include "parameters.h"

void inference(
	hls::stream<axis_int_t>& input,
	int *result
) {

    //#pragma HLS INTERFACE mode=s_axilite port=return
    #pragma HLS INTERFACE mode=ap_ctrl_hs port=return
    #pragma HLS INTERFACE axis register both port=input
    #pragma HLS INTERFACE ap_vld port=result register
    // #pragma HLS PIPELINE

#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        // hls-fpga-machine-learning insert load weights
        nnet::load_weights_from_txt<weight2_t, 3920>(w2, "w2.txt");
        nnet::load_weights_from_txt<bias2_t, 5>(b2, "b2.txt");
        nnet::load_weights_from_txt<weight5_t, 25>(w5, "w5.txt");
        nnet::load_weights_from_txt<bias5_t, 5>(b5, "b5.txt");
        nnet::load_weights_from_txt<weight8_t, 10>(w8, "w8.txt");
        nnet::load_weights_from_txt<bias8_t, 2>(b8, "b8.txt");
        loaded_weights = true;
    }
#endif
    input_t fc1_input_input[N_INPUT_1_1];
    result_t layer10_out[N_LAYER_8];

    axis_int_t val;

    for(int h=0; h<N_INPUT_1_1; h++){

    #pragma HLS PIPELINE

                // Read and cache value
                val = input.read();
                fc1_input_input[h] = val.data/255;

            }


    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    layer2_t layer2_out[N_LAYER_2];
    #pragma HLS ARRAY_PARTITION variable=layer2_out complete dim=0
    nnet::dense<input_t, layer2_t, config2>(fc1_input_input, layer2_out, w2, b2); // fc1

    layer4_t layer4_out[N_LAYER_2];
    #pragma HLS ARRAY_PARTITION variable=layer4_out complete dim=0
    nnet::linear<layer2_t, layer4_t, linear_config4>(layer2_out, layer4_out); // relu1

    layer5_t layer5_out[N_LAYER_5];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0
    nnet::dense<layer4_t, layer5_t, config5>(layer4_out, layer5_out, w5, b5); // fc2

    layer7_t layer7_out[N_LAYER_5];
    #pragma HLS ARRAY_PARTITION variable=layer7_out complete dim=0
    nnet::linear<layer5_t, layer7_t, linear_config7>(layer5_out, layer7_out); // relu2

    layer8_t layer8_out[N_LAYER_8];
    #pragma HLS ARRAY_PARTITION variable=layer8_out complete dim=0
    nnet::dense<layer7_t, layer8_t, config8>(layer7_out, layer8_out, w8, b8); // output
    //std::cout<< "before softmax "  << std::endl;
    //std::cout<< "Output 0: " << layer8_out[0] << std::endl;
    //std::cout<< "Output 1: " << layer8_out[1] << std::endl;

    nnet::softmax<layer8_t, result_t, softmax_config10>(layer8_out, layer10_out); // softmax
    //std::cout<< "after softmax "  << std::endl;
    //std::cout<< "Output 0: " << layer10_out[0] << std::endl;
    //std::cout<< "Output 1: " << layer10_out[1] << std::endl;

    if(layer8_out[1] < 0){
        // result tiene el valor de la clase (del tipo int) que desea mostrar por la terminal.
            *result = 5;
        } else{
            *result = 7;
        }
}
